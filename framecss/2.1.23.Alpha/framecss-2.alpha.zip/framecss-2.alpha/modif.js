/*const h1 = document.querySelector("h1");
h1.textContent = "H1 : dari modif.js";

*/


// mulai modifikasi....
// *****************************************


/*
modifikasi JavaScript sesuai keinginan mu
*animasi
*durasi
*filter
*efek
*/